## When Using Design Toolkit

1. Only use icons from `@accelint/icons`.
2. Check component props via typescript definitions (`package.json#types`) and examples via Storybook (`**/**.docs.mdx`) documentation before using.
