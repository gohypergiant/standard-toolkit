# @accelint/design-toolkit

## 9.4.0
### Minor Changes

- a8ce0bc: Refactors existing implementation of DrawerClose event to now emit a new event tied to an ID, to allow for listening to bus for Drawer Open and Close. Previously, the viewstack would be cleared without emitting an event with a given id.

### Patch Changes

- ab729dc: Changed icon imports to use full path
- 075f526: fix: Updates the outline color of text-area-field to correct color and fixes the right padding of the coordinate-field
- 669a261: move some lingering inline utility classes to css modules
- 975f690: chore: expose more drawer / drawer-layout props in their stories; update their docs for any missing props
- f577fef: Fixed issue with Popover where dialogProps is not being passed down to child Dialog component
- c73558a: Fix keyboard event trigger for coordinate field copy popover
- c3f5b00: Update the default variant for toggle buttons from the incorrect `filled` to `flat`. Types exclude `filled` variant from ToggleButtons

## 9.3.0
### Minor Changes

- 0872e9e: Add DeferredCollection component to lazy load large collections when virtualizing.
- eb23d75: Modified tailwind variant definition for readonly. Also added readonly support for the following components: ComboboxField, CoordinateField, DateField, SelectField, TextAreaField, TextField, and TimeField
- 2fb19ee: Adds `elevation-overlay` and `elevation-raised` variants to design-foundation for use with `data-elevation` attribute
  
  Adds `elevation` prop to the ActionBar component with options `flat`, `overlay`, and `raised` to allow configurable shadow styling
- d06b13a: Add composition examples showing how to combine Button with Menu

### Patch Changes

- cf0c6f3: Fix granularity argument in the DateField story
- 606b0ea: Fix the drawer menu 'end' placement styling
- beedb2d: Fix menu separator visibility
- Updated dependencies [45275c4]
- Updated dependencies [eb23d75]
- Updated dependencies [d328b71]
- Updated dependencies [2fb19ee]
  - @accelint/geo@0.5.1
  - @accelint/design-foundation@2.1.0
  - @accelint/logger@0.1.5

## 9.2.0
### Minor Changes

- 7e80a87: Add list component

### Patch Changes

- 9a31d4f: Add a story to highlight inputProps for the TextField component
- 8a013b7: Add a story to demonstrate selection state for options
  - @accelint/design-foundation@2.0.0
  - @accelint/icons@2.1.2

## 9.1.1
### Patch Changes

- 4124007: Added a focus outline style on the <Accordion /> header button.
- 308023f: Increase decimal precision in coordinate field conversion
- 8ab9bfd: Fixed spacing of visual elements (prefix, suffix, clear button) in Input
- Updated dependencies [308023f]
  - @accelint/geo@0.5.0

## 9.1.0
### Minor Changes

- 4199d27: Added the stacked and inline variants to the CoordinateField component. It defaults to the inline variant.
- 1ddcadf: Ensure proper resolution of RAC dependencies for library and consumers.

### Patch Changes

- f99db0b: Fixed an issue with SearchField where the container stretches vertically within a flex parent container

## 9.0.0
### Major Changes

- 6bc3a0b: Remove /styles export. Convert utility class usage in src to css modules.
  
  Breaking Changes:
  * `/styles` export has been removed
    * because all component styles are in css modules and global classes live in design-foundation, there is no longer anything global for the design toolkit to export
  
  Migration Guide:
  * [Visit the v9 migration guide](https://design-toolkit.accelint.io/?path=/docs/upgrade-guides--playground) for detailed information about migration
- 16d23c4: Build with tsdown
  
  Breaking Changes:
  * `/index` has been removed from the end of deep import paths
    * e.g. `import { designTokens } from '@accelint/design-foundation/tokens/index';` is now `import { designTokens } from '@accelint/design-foundation/tokens'`;
  
  Migration Guide:
  * [Visit the v9 migration guide](https://design-toolkit.accelint.io/?path=/docs/upgrade-guides--playground) for detailed information about migration

### Patch Changes

- 4af2d58: Fixed accordion where the trigger disabled cursor was incorrect (pointer -> not-allowed)
- a851031: fix: chip component bug where color prop was not supported by selectableChip
- 471d963: Pin RAC dependencies to exact versions to prevent breaking changes.
- bb73a1e: Ensure dependencies all follow the same semver range across devtk, maptk, and designtk.
- 55ce09a: Fixed accordion where the collapsed disclosure component takes up space
- 2f6d9b3: Add use client directive to dialog trigger
- 77fa9d0: Ensure slider track value css vars are set
- Updated dependencies [16d23c4]
- Updated dependencies [bb73a1e]
  - @accelint/design-foundation@2.0.0
  - @accelint/temporal@0.1.4
  - @accelint/logger@0.1.4
  - @accelint/icons@2.1.2
  - @accelint/core@0.5.2
  - @accelint/bus@3.0.2
  - @accelint/geo@0.4.2

## 8.1.2
### Patch Changes

- 00f3d35: Updates data type for MenuSection to allow for title to be a ReactElement in addition to a string.
- 2281c63: - Added comprehensive test suite (15 tests, 100% coverage) for CSS module hashing logic
  - Added typecheck script to design-toolkit package.json
  - Added separate troubleshooting guide for CSS module issues
  - Added detailed JSDoc documentation for CSS module hashing function
- c1c3fbc: Fix button styles when variant=outline and color=critical or serious
- Updated dependencies [34c42a0]
- Updated dependencies [2281c63]
  - @accelint/temporal@0.1.3
  - @accelint/logger@0.1.3
  - @accelint/icons@2.1.1
  - @accelint/core@0.5.1
  - @accelint/bus@3.0.1
  - @accelint/geo@0.4.1
  - @accelint/design-foundation@1.0.2

## 8.1.1
### Patch Changes

- Updated dependencies [01bdf1e]
  - @accelint/design-foundation@1.0.1

## 8.1.0
### Minor Changes

- 2a7c001: Adds Flashcard, A display component to quickly summarize information at a glance, with multiple options to show data.
- c15d06f: Add features from TanStack Table to Table component: column width, selection change callback.

### Patch Changes

- cfe734a: Fix @accelint/geo UTM parsing and formatting. UTM format will no longer return MGRS format.
- 582dfd9: Add @accelint/logger as a peer dependency to design-toolkit
- Updated dependencies [cfe734a]
  - @accelint/geo@0.4.0

## 8.0.0
### Major Changes

- f3a9fb3: This release contains a number of breaking changes and will require some migration steps. For detailed information about why the changes were made and how to migrate, [consult our v8 migration guide](https://design-toolkit.accelint.io/?path=/docs/upgrade-guides--playground).
  
  Breaking Changes:
  * Removed support for Tailwind Variants in Design Foundation - functions `tv`, `mergeVariants` and `twMerge` are no longer exported
  * Badge & Chip prop `variant` is renamed to `color` to align with Button
  * Popover structure updated – PopoverTrigger is now the root; triggerable elements and popover content must be direct children.
  * `sudo:` custom variant utility removed.
  
  Improvements:
  * Introducing CSS modules as another tool for working with Tailwind
  * Components now use 1–3 core classes instead of large utility sets.
  * State-based styles are applied only when active, reducing DOM noise.
  * Variant syntax updated: use @variant blocks with @apply instead of chained selectors.
  * CSS layer system expanded: `components.l1–l5` for controlled style precedence; use higher layers (l3–l5) or @utilities for overrides.
  * Improved CSS validation – invalid class names now throw errors during compilation.
  * Eliminated CPU-intensive TV/tw-merge resolution; runtime performance improved at scale.
  
  New Features:
  * Added additional custom variants: extend-left/right/top/bottom, push-left/right/top/bottom.
  * Action Bar: added size prop for flexible usage.
  
  Migration Guide:
  * [Visit the v8 migration guide](https://design-toolkit.accelint.io/?path=/docs/upgrade-guides--playground) for detailed information about migration
  * CSS Modules are required – Next.js supports out-of-the-box; other frameworks may need setup.
  * Named group classes (group/*) must not be hashed – use provided generateScopedClassName (Vite) or getLocalIdent (Webpack/Next.js).
  * Use `clsx` exported from the DTK for conditional class composition rather than `tv` at the path `@accelint/design-foundation/lib/utils`
  * When using css modules in your application, avoid composes – external composes bypass Tailwind processing
- 80db585: BREAKING CHANGES:
  Design Toolkit no longer exports `tv`, this is now available from Design Foundation
  
  Created new package @accelint/design-foundation that houses all of the Tailwind tokens, variants, base styles and utilities for easier reuse without having a dependency on the larger Design Toolkit
  
  Updated Map Toolkit Storybook and NextJS demo app styles to import the new Design Foundation

### Minor Changes

- 3f9d14b: Added a Kanban component with a drag-and-drop board for organizing tasks and workflows.
- 3d6a25b: Add prefix and suffix to (text) Input and TextField components.
- e463867: New feature added: Pagination. A lightweight implementation to allow users to navigate pages, with previous and next links.
- b48a3bd: Add CoordinateField component with support for multiple coordinate systems (DD, DDM, DMS, MGRS, UTM).

### Patch Changes

- a5dfc06: Update all fields component to have the correct width
- 874edd5: ## Breaking Change: Structured Clone Constraint
  
  The event bus payload is now constrained to values that are serializable by the [structured clone algorithm](https://developer.mozilla.org/en-US/docs/Web/API/Web_Workers_API/Structured_clone_algorithm). This constraint aligns the TypeScript types with the actual runtime behavior of the `BroadcastChannel` API.
  
  ### What this means
  
  You can no longer pass the following types in event payloads:
  
  - Functions
  - Symbols
  - DOM nodes
  - Prototype chains (class instances lose their methods)
  - Properties with `undefined` values (they're omitted)
  
  ### How to migrate
  
  **❌ Before:**
  
  ```typescript
  bus.emit('user-action', {
    callback: () => console.log('done'), // ❌ Function
    userData: userClass, // ❌ Class instance with methods
    element: document.getElementById('foo'), // ❌ DOM node
  });
  ```
  
  **✅ After:**
  
  ```typescript
  // Option 1: Send only data, handle logic separately
  bus.emit('user-action', {
    actionType: 'complete', // ✅ Primitive
    userData: { id: userClass.id, name: userClass.name }, // ✅ Plain object
    elementId: 'foo', // ✅ Reference by ID
  });
  
  // Option 2: Use event types to trigger behavior
  bus.on('user-action-complete', () => {
    console.log('done'); // Handle callback logic in listener
  });
  ```
  
  ### Supported types
  
  - Primitives (string, number, boolean, null, BigInt)
  - Plain objects and arrays
  - Date, RegExp, Map, Set
  - Typed arrays (Uint8Array, etc.)
  - ArrayBuffer, Blob, File
  
  ### Finding issues
  
  TypeScript will now catch most violations at compile time. Runtime errors from `BroadcastChannel.postMessage()` indicate non-serializable values that slipped through.
- 2470426: Updates the styling of the last child in breadcrumb to match designs
- 4ca8fe5: fixes semantic token discrepancy
  
  plus updates state styles of switch, text-area-field, checkbox, option-item and menu-item
- 67edb84: Fixes an issue where the MenuTrigger and DrawerTrigger components were not being properly exported.
- abc5365: Fix issue where the timer does not start unless hovered for notices.
- Updated dependencies [f3a9fb3]
- Updated dependencies [80db585]
- Updated dependencies [874edd5]
- Updated dependencies [e8535c4]
  - @accelint/design-foundation@1.0.0
  - @accelint/bus@3.0.0

## 7.0.1

### Patch Changes

- 0093e60: Fix issue with use client directive prepend logic not working during build

## 7.0.0

### Major Changes

- 3d71b8d: Refactored the DesignToolkit so that it does not use the dot syntax anymore. As an example, `Drawer.Header` is now `DrawerHeader` and so on. This change is required to avoid RSC throwing `undefined` errors in some cases when rendering.

  This is a breaking change and will require removing the dot notation from components currently in use in your code base.

  This change also updates the import/export paths for the components. If you are not importing from the root `@accelint/design-toolkit` path, then you will need to update your imports as follows:
  - `RootComponent` goes from `@accelint/design-toolkit/root-component` to `@accelint/design-toolkit/components/root-component/index`
  - `RootComponentHeader` goes from `@accelint/design-toolkit/root-component` to `@accelint/design-toolkit/components/root-component/header`

### Minor Changes

- 5b62458: Removed all component composition validation due to it not working with SSR/RSC
- ea4f348: Updating table component to include documentation and also add event handlers to handle server side logic
- cec6fee: Replace lodash with radashi for performance and build size optimization
- 5ce2a0c: Adds new map-related icons to the icon library set

### Patch Changes

- 842e84a: Updates state styles of select
- 0d697fa: Fixed definitions in package files for longhand repository definitions, while disabling the option in syncpack that changed it.
- d10c518: Memoize the overlay container for tooltip to prevent detached node
- face3c9: Replaces style syntax errors in Checkbox and Tree that were preventing correct style application
- d67c471: Audits state styles of switch
- f031f36: Updates radio state styles
- 0d0edc4: Document the custom value implementation for combobox
- ef52380: bump to node 22
- f5a2a9f: Updates color-picker state styles
- 8d81c70: Updates state styles of option items and menu items plus fixes a semantic token discrepancy
- f99f294: Updated syncpack and realigned all packages for dependency versions
- b5061d2: Updates state styles of checkbox
- 935b8e5: Updated the package names in the Constellation configuration file.
- cfd8d43: Update the width of the select field component
- 0c5e77f: State style updates plus propagates disabled state to slider
- 2f1b9c6: address the console errors/warnings during test runs
- 1c2a622: Updates deletable chip and selectable chip state styles
- Updated dependencies [0d697fa]
- Updated dependencies [f99f294]
- Updated dependencies [935b8e5]
- Updated dependencies [525a5a6]
- Updated dependencies [5ce2a0c]
  - @accelint/icons@2.1.0
  - @accelint/temporal@0.1.2
  - @accelint/core@0.5.0
  - @accelint/bus@2.0.0

## 6.0.0

### Major Changes

- 6d131cd: A refactor introducing breaking changes for the Tooltip component. The structure is now a light wrapper around the [Tooltip](https://react-spectrum.adobe.com/react-aria/Tooltip.html) implementation. Tooltip has been replaced with Tooltip.Trigger and Tooltip.Body has been replaced with Tooltip. Reference the [docs](https://gohypergiant.github.io/standard-toolkit/?path=/docs/components-tooltip--playground) for implementation instructions.
- ac5378e: Changed to new naming system for fontsource.

  Breaking change: This will require changing packages downstream according to the [v5 migration blog](https://fontsource.org/docs/getting-started/migrate-v5) on fontsource.

  Example:

  From this:

  ```json
      "@fontsource/roboto-flex": "^5.2.8",
      "@fontsource/roboto-mono": "^5.2.8",
  ```

  To:

  ```json
      "@fontsource-variable/roboto-flex": "^5.2.8",
      "@fontsource-variable/roboto-mono": "^5.2.8",
  ```

### Minor Changes

- 23ad1db: This release introduces a Notice component to display notifications, alerts, and messages. The implementation includes an individual Notice component for single notifications and Notice.List for queue-based notifications. The system supports five color variants (info, advisory, normal, critical, and serious) with customizable action buttons, automatic timeout management, flexible dequeuing options, and portal-based rendering. View the [Notice component in Storybook](https://gohypergiant.github.io/standard-toolkit/?path=/docs/components-notice--playground) for interactive examples and documentation.
- 0baf4b0: This fixes a memory leak in the ViewStack component that affects the Drawer component causing detached elements.
- ade0504: - export ThemeMode type (light or dark)for use in the ThemeProvider
  - apply bg-surface-default and fg-primary-bold tokens to the html element by default
  - move font-primary token from the body element to the html
- eba4ac3: Adds Clock component

### Patch Changes

- 66ac503: Fixes incorrect link to the Github repository
- 3e47dea: Updates state styles of tree
- 57efc27: Updates state styles for tabs
- d625d2b: Apply story patterns: satisfies, story type alias, meta property ordering
- 1e68e16: Updates state styles of combobox
- fb2852d: add missing docblock comments to publicly exported components
- 5643ee1: Fixed buttons min/max widths being incorrectly applied
- 64280a7: - Released `@accelint/constellation-tracker` - A tool that helps maintain catalog-info.yaml files for Constellation integration
  - Ensures all packages include catalog-info.yaml in their published files for better discoverability and integration with Constellation
  - Provides automated tracking and updating of component metadata across the project
  - Enhanced package metadata to support better integration with internal tooling
- 4d96d59: Fixes an issue where the Slider component had a fixed height instead of being sized according to its content.
- 65a0137: Link state style updates
- d726ad5: Accordion/AccordionGroup variant styling has been updated to address a bug that was not displaying correctly.
- Updated dependencies [66ac503]
- Updated dependencies [ccb2d05]
- Updated dependencies [64280a7]
  - @accelint/icons@2.0.4
  - @accelint/bus@1.4.0
  - @accelint/core@0.4.2
  - @accelint/temporal@0.1.1

## 5.2.0

### Minor Changes

- c6881e4: Adds Table component to DesignTK
- fc4d913: Adds Tooltip to Drawer.Menu.Item via textValue prop
- ff7094f: Removes non-functional `isReadOnly` prop from `SelectField`
- 438fd64: - Fixes discrepancies in color tokens to be more closely aligned with Figma.
  - Updates certain color token primitives to reflect changes.
  - Updates styling for the accordion component to reflect new changes in the Button component, specifically in the pressed state.
  - Removes the hover state for disabled icon button/toggle button
- a302ed8: - Update styling and states for Button, IconButton, ToggleButton
  - Removes support for color variant 'info'
  - Removes support for floating and filled variants for ToggleButton
- d5ee78f: Fixes Drawer.Menu overflow
- b4348ac: Refactors header to add opinionated variant
- 4026632: Adds Breadcrumb component
- b4ef537: Adds Divider component
  - Utilizes Divider in Sidenav as a replacement for custom implementation

### Patch Changes

- 87d6eb1: Applies pressed state style to search-field
- 69b9aff: Adds correct cursor styling to menu-items
- f216426: Creates a pressed state for input
- Updated dependencies [b11870c]
- Updated dependencies [6374c68]
  - @accelint/bus@1.3.0

## 5.1.0

### Minor Changes

- 011a70a: Fix missing client-only import for classification banner
  Normalize tailwind-variant usage across components
- 030bfde: Add Sidenav.Menu component
- 9c4c834: Preserve 'use client' directive

### Patch Changes

- 5206880: Linting fixes only.
- Updated dependencies [5206880]
  - @accelint/core@0.4.1

## 5.0.0

### Major Changes

- 7ab50ad: Major theme updates --
  - Adding theme support for light mode
  - Renaming selected design tokens for light mode compatibility
  - Script for token naming migrations
  - Default accent color update from seafoam green to accelint skyfoam blue
  - Shift to using tailwind utility classes for color to better align with token names

### Minor Changes

- 8505551: Add ActionBar component
- 851cf04: Add Sidenav.Avatar component
- 0f49fbd: Implement both button and toggle button providers
- c433ae0: Add sidenav component with header, item, and divider
- aab4161: Add Sidenav.Link component
- 14102a3: Add link component
- a793f6d: Add missing doc blocks and update existing doc blocks to follow standards
- a526c71: adds <Tree> component
- 37fb8af: Refactor the Tabs compononent to meet style standards

### Patch Changes

- d82e2fe: fix: remove extraneous parameters for event bus
- Updated dependencies [55718af]
  - @accelint/bus@1.2.0
  - @accelint/icons@2.0.3

## 4.0.0

### Major Changes

- 9660517: Removes range slider and implements style standards

### Minor Changes

- f03040f: Refactor dialog to meet style standards
- 9d576f8: Update to latest react-aria-components version 1.12.1

### Patch Changes

- 2848d9b: Remove unnecessary global selectors
- 7e56878: Added a utility method to run Tailwind Merge across variants.
- Updated dependencies [e767f7c]
  - @accelint/bus@1.1.0

## 3.0.0

### Major Changes

- 57d61c4: Added docblocks; removed Box component

### Minor Changes

- e06fb14: Consolidate button styles to reduce complexity
- 0d92211: refactor button colors
- d3dcc87: Refactored Drawer to be event driven

### Patch Changes

- 13c065b: Made Menu Section title conditionally rendered
- a7da3db: added labelPosition prop to Switch component
- cd684ca: Fixed Combobox styles
- 0701f3b: Fixed default Input size
- f6d0be1: Switch to using focus visible for most focus states
- ed09b0d: Added back in missing default for color of buttons
- Updated dependencies [cdd91b3]
- Updated dependencies [0457dc6]
  - @accelint/core@0.4.0
  - @accelint/bus@1.0.0

## 2.6.0

### Minor Changes

- a97d386: Update Menu component to accept custom triggers
  Add Hotkey component
- 9ec4cbe: Adds <select> component

### Patch Changes

- 83104ea: Refactored ViewStack to be event driven, allowing for triggers anywhere in the app
- Updated dependencies [83104ea]
- Updated dependencies [83104ea]
  - @accelint/core@0.3.0
  - @accelint/icons@2.0.3
  - @accelint/bus@0.1.2

## 2.5.0

### Minor Changes

- 5404e48: Refactor SearchField to follow styling standards
- 61a55ef: Add drawer

### Patch Changes

- 11a813f: Fix css grid formatting for menu
- 7481c80: Update Options to follow DesignTK styling standards
- a201c50: Updated types and fixtures in query builder to fix build
- de8c60a: remove duplicative type prop from TextField
- 484c14f: Added default text color for filled buttons
- a16fbf3: - Created DetailsList component
  - Created Hero component
  - Created Skeleton component
  - Simplified types
  - Implemented missing tests
  - Updated component structure validation functions to exit early in production
  - Expanded component structure validation functions to handle RACs, functions and Fragments
- c95e5b4: allow children
- Updated dependencies [ca3922a]
  - @accelint/icons@2.0.2

## 2.4.3

### Patch Changes

- 382bbc2: Fixes a build issue caused by an import with trailing character in `components/avatar/index.tsx`.

## 2.4.2

### Patch Changes

- 93b3750: Fixed controlled usage of field input

## 2.4.1

### Patch Changes

- f57cb86: Adds fallback for some css tokens
- 4fa066a: - Converted Input autoSize behavior to an optional prop variant
  - Lowered custom variant selector specificity to reduce friction of overrides
  - Fixed Checkbox styling for state of indeterminate + disabled

## 2.4.0

### Minor Changes

- fe10a47: Adds the <menu> component

### Patch Changes

- 4dd70f2: - Add Input component with automatic resizing
  - Refactor TextField to new style standard and to use new Input
  - Fix Checkbox foreground color
  - Fix outline inset
  - Add typography spacing tokens
- c16b479: Removed plural naming for shadow tokens
- 51422c1: Remove menu icon and menu keyboard exports
- 9421185: Remove Menu.Item.Icon and Menu.Item.Keyboard and cleanup styles
- a502977: Fix accordion icon not flipping
- 34f3d91: - Flattened token folder structure for easier use within DesignTK
  - Added group names to deconflict Tailwind groups
  - Converted size to variant selector
  - Added missing provider
- f9e0cac: Refactored Avatar & Badge to new styling standard

## 2.3.2

### Patch Changes

- ad067b2: - Update DesignTK Checkbox to follow styling standards
  - Remove Checkbox and Radio icons due to not being implementable as-is
- Updated dependencies [ad067b2]
  - @accelint/icons@2.0.1

## 2.3.1

### Patch Changes

- 32b4176: Fixes incorrect pluralization of icons css vars

## 2.3.0

### Minor Changes

- 56e2555: add script to build phase to generate css vars and ts variables for tokens to ensure a single source of truth

### Patch Changes

- 8879858: Refactor component styles to use variant selectors
- 8440a09: Refactored buttons to share styles
- 038f012: Replaced RAC TW plugin with custom variants that merge with CSS pseudo classes making variant selectors agnostic of RAC
- 6bf21ea: Refactored TextArea to be consistent in standards
- 0e0125a: - Refactored Chip to conform to new standards
  - Added Chip context provider
  - Swapped Chip span out for div for consistency
- 0089039: Conditionally render icon containers in OptionsItem
- 61488e3: Refactor Radio to follow styling standards
- b283521: refactor classification banner to use tailwind-variants
- aca19ec: refactor classification badge component to use twv
- 8b0d1eb: - Refactored Label & Switch to be consistent in standards
  - Swapped Label isOptional for isRequired for consistency
  - Added contexts and providers
- c83d321: Simplified Accordion styles based on variant selectors

## 2.2.1

### Patch Changes

- 0fd9e71: Fixes an issue where certain components were not properly marked as client components.

## 2.2.0

### Minor Changes

- 301e690: Add popover component
- 006587b: Set default to primary font

### Patch Changes

- 1f3c039: Ensure complete exports

## 2.1.0

### Minor Changes

- 9a5eff5: Added slider and range slider component
- 3f382f2: Update react-aria-component and associated libraries to latest
- e1ca0ad: added options component

### Patch Changes

- cb2ec56: - Established new styling standard for DesignTK
  - Converted DesignTK Tailwind prefix from ai- to dtk-
  - Made object member casing more flexible and consistent across all packages
  - Upgraded TS types for React to be consistent and fix type conflicts
- 6f4aad2: - Updated Icon to use separated styles
  - Added Icon provider for easy prop spreading to multiple Icons
  - Handled style overrides from parent and locally
  - Added icon size vars to config to globalize mapping

## 2.0.0

### Minor Changes

- 3c9a57a: Added the Tabs component along with its subcomponents
- 283cc55: Add SearchField component
- 3e374a2: Add <QueryBuilder> component
- a0c80d0: added DateField component
- e92adc6: Added the Dialog component.
- 3b9c678: added ColorPicker component to DesTK

### Patch Changes

- 5ee48c2: fixed combobox layout
- 3e374a2: Added the ComboBox component.
- Updated dependencies [6d07b28]
  - @accelint/icons@2.0.0

## 1.0.1

### Patch Changes

- 0c66cab: added virtualizer to combobox component
- 032e278: Added the ComboBox component.

## 1.0.0

### Patch Changes

- 1cab20a: Updated the TextField and TextArea components to also pass props down to the underlying HTML elements.
- Updated dependencies [4974392]
  - @accelint/icons@1.1.0

## 0.0.2

### Patch Changes

- 777e708: Adds the Checkbox and Checkbox.Group components
- cedce42: Added the <Accordion> and <Accordion.Group> components to the design system.
- 0ed1888: Added the TextField component.
- c5fbdbd: Added the <Switch> component.
- 06fc5c9: Added the Radio and Radio.Group components.
- ca58974: Added the initial scaffolding for documentation to the existing components.
- c5186e8: Added the <TextArea> component.
- 636e3dc: Updated dependencies.
- Updated dependencies [0278535]
  - @accelint/icons@2.0.0

## 0.0.1

### Patch Changes

- 4047209: Initial Release
