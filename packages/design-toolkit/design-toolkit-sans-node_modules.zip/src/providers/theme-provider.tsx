/*
 * Copyright 2025 Hypergiant Galactic Systems Inc. All rights reserved.
 * This file is licensed to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 * OF ANY KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */

'use client';

import 'client-only';
import { designTokens } from '@accelint/design-foundation/tokens';
import { assign } from 'radashi';
import {
  createContext,
  type PropsWithChildren,
  useContext,
  useEffect,
  useMemo,
  useState,
} from 'react';
import type {
  SemanticColorTokens,
  StaticColorTokens,
  ThemeTokens,
} from '@accelint/design-foundation/tokens/types';
import type { PartialDeep } from 'type-fest';

/** Theme mode for light or dark appearance */
export type ThemeMode = 'dark' | 'light';
type ContextColorTokens = SemanticColorTokens & StaticColorTokens;

type ThemeContextValue = {
  mode: ThemeMode;
  tokens: ContextColorTokens;
  toggleMode: (mode: ThemeMode) => void;
};
/** provide default context value to avoid optional chaining and null checks on the client */
const defaultContextValue: ThemeContextValue = {
  mode: 'dark',
  tokens: { ...designTokens.dark, ...designTokens.static },
  toggleMode: (_mode) => {
    // no-op
  },
};
const ThemeContext = createContext<ThemeContextValue>(defaultContextValue);

type ThemeProviderProps = PropsWithChildren & {
  defaultMode?: ThemeMode;
  onChange?: (mode: ThemeMode) => void;
  /** override existing values in the theme */
  overrides?: PartialDeep<ThemeTokens>;
};

/**
 * Provides theme context with mode toggling and token overrides
 *
 * @param props - {@link ThemeProviderProps}
 * @param props.children - Content to render within the theme context.
 * @param props.defaultMode - Initial theme mode (defaults to 'dark').
 * @param props.onChange - Callback when theme mode changes.
 * @param props.overrides - Partial overrides for theme tokens.
 * @returns The theme provider wrapping children.
 */
export function ThemeProvider({
  children,
  defaultMode,
  onChange,
  overrides,
}: ThemeProviderProps) {
  const [mode, setMode] = useState<ThemeMode>(defaultMode ?? 'dark');

  useEffect(() => {
    if (document) {
      const { documentElement } = document;
      documentElement.classList.remove('dark', 'light');
      documentElement.classList.add(mode);
    }
  }, [mode]);

  const tokens: ContextColorTokens = useMemo(() => {
    const tokensWithOverrides = assign(designTokens, overrides as ThemeTokens);
    return {
      ...tokensWithOverrides[mode],
      ...tokensWithOverrides.static,
    };
  }, [mode, overrides]);

  return (
    <ThemeContext.Provider
      value={{
        mode,
        tokens,
        toggleMode: (mode: ThemeMode) => {
          setMode(mode);
          onChange?.(mode);
        },
      }}
    >
      {children}
    </ThemeContext.Provider>
  );
}

/**
 * Access the current theme context
 *
 * @returns Theme context with mode, tokens, and toggleMode function.
 */
export function useTheme() {
  return useContext(ThemeContext);
}
