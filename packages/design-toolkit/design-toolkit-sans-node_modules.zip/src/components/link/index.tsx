/*
 * Copyright 2025 Hypergiant Galactic Systems Inc. All rights reserved.
 * This file is licensed to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 * OF ANY KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
'use client';

import 'client-only';
import { clsx } from '@accelint/design-foundation/lib/utils';
import {
  Link as AriaLink,
  composeRenderProps,
  LinkContext,
  useContextProps,
} from 'react-aria-components';
import styles from './styles.module.css';
import type { LinkProps } from './types';

/**
 * Link - Accessible anchor/link component with optional visited state
 *
 * A flexible link component that handles visited state, external anchors, and
 * icon integration while providing ARIA-compatible behavior.
 *
 * @param props - {@link LinkProps}
 * @param props.ref - Ref to the anchor element.
 * @param props.allowsVisited - Whether the link shows visited styling when visited.
 * @param props.className - Optional CSS class name.
 * @param props.isVisited - Whether the link is in a visited state.
 * @returns The rendered Link component.
 *
 * @example
 * ```tsx
 * <Link href="/dashboard">Go to Dashboard</Link>
 * ```
 */
export function Link({ ref, ...props }: LinkProps) {
  [props, ref] = useContextProps(props, ref ?? null, LinkContext);

  const {
    allowsVisited = false,
    className,
    isVisited = false,
    ...rest
  } = props;

  return (
    <AriaLink
      {...rest}
      ref={ref}
      className={composeRenderProps(className, (className) =>
        clsx(styles.link, className),
      )}
      data-visited={(allowsVisited && isVisited) || null}
    />
  );
}
