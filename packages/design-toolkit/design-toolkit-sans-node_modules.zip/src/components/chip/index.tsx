/*
 * Copyright 2025 Hypergiant Galactic Systems Inc. All rights reserved.
 * This file is licensed to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 * OF ANY KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
'use client';

import 'client-only';
import { clsx } from '@accelint/design-foundation/lib/utils';
import { useContext } from 'react';
import { Tag as AriaTag, useContextProps } from 'react-aria-components';
import { IconProvider } from '../icon/context';
import { ChipContext } from './context';
import { ChipListRenderingContext } from './list';
import styles from './styles.module.css';
import type { ChipProps } from './types';

/**
 * Chip - A compact element for displaying tags, filters, or selectable items
 *
 * Provides flexible chip functionality supporting both individual chips and chip lists.
 * Includes variants for deletable and selectable chips with keyboard navigation and
 * accessibility features. Perfect for tags, filters, or multi-selection interfaces.
 *
 * @param props - The chip props.
 * @param props.ref - Reference to the chip element.
 * @param props.className - Additional CSS class names for styling.
 * @param props.color - Semantic color variant.
 * @param props.size - Size of the chip.
 * @param props.children - Chip content (text, icons, or both).
 * @returns The chip component.
 *
 * @example
 * ```tsx
 * // Basic chip
 * <Chip>JavaScript</Chip>
 * ```
 *
 * @example
 * ```tsx
 * // Chip with color variants
 * <Chip color="info">Information</Chip>
 * <Chip color="advisory">Warning</Chip>
 * <Chip color="normal">Success</Chip>
 * <Chip color="serious">Caution</Chip>
 * <Chip color="critical">Error</Chip>
 * ```
 *
 * @example
 * ```tsx
 * // Chip with icon
 * <Chip color="info">
 *   <Icon><Placeholder /></Icon>
 *   With Icon
 * </Chip>
 * ```
 *
 * @example
 * ```tsx
 * // Chip with size variants
 * <Chip size="medium">Medium Chip</Chip>
 * <Chip size="small">Small Chip</Chip>
 * ```
 *
 * @example
 * ```tsx
 * // Chip list with multiple items
 * <ChipList>
 *   <Chip color="info">React</Chip>
 *   <Chip color="advisory">TypeScript</Chip>
 *   <Chip color="normal">Node.js</Chip>
 * </ChipList>
 * ```
 *
 * @example
 * ```tsx
 * // Deletable chips
 * <ChipList onRemove={(keys) => console.log('removed', keys)}>
 *   <DeletableChip id="tag1">Removable Tag</DeletableChip>
 * </ChipList>
 * ```
 *
 * @example
 * ```tsx
 * // Selectable chips with color
 * <ChipList selectionMode="single">
 *   <SelectableChip id="up" color="normal">UP</SelectableChip>
 *   <SelectableChip id="down" color="critical">DOWN</SelectableChip>
 * </ChipList>
 * ```
 */
export function Chip({ ref, ...props }: ChipProps) {
  [props, ref] = useContextProps(props, ref ?? null, ChipContext);

  const context = useContext(ChipListRenderingContext);
  const Component = context ? AriaTag : 'div';
  const { className, color = 'info', size = 'medium', ...rest } = props;

  return (
    <IconProvider size={size === 'medium' ? 'small' : 'xsmall'}>
      <Component
        {...rest}
        ref={ref}
        className={clsx('group/chip', styles.chip, className)}
        data-color={color}
        data-size={size}
      />
    </IconProvider>
  );
}
