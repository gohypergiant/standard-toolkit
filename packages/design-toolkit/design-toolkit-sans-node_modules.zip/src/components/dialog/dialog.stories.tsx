/*
 * Copyright 2025 Hypergiant Galactic Systems Inc. All rights reserved.
 * This file is licensed to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 * OF ANY KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */

import { useCallback, useRef, useState } from 'react';
import { Button } from '../button';
import { DialogContent } from './content';
import { DialogFooter } from './footer';
import { Dialog } from './index';
import { DialogTitle } from './title';
import { DialogTrigger } from './trigger';
import type { Meta, StoryObj } from '@storybook/react-vite';

const meta = {
  title: 'Components/Dialog',
  component: Dialog,
  args: {
    size: 'small',
    isDismissable: true,
    isKeyboardDismissDisabled: false,
  },
  argTypes: {
    size: {
      control: 'select',
      options: ['small', 'large'],
    },
    isDismissable: {
      control: 'boolean',
    },
    isKeyboardDismissDisabled: {
      control: 'boolean',
    },
  },
} satisfies Meta<typeof Dialog>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {
  render: ({ children, ...args }) => {
    // NOTE: the ref here is only for Storybook -- you can omit that in your application code
    const ref = useRef(null);
    return (
      <div
        className='relative h-[800px] w-[600px] p-l outline outline-info-bold'
        ref={ref}
      >
        <DialogTrigger>
          <Button>Press Me</Button>
          <Dialog {...args} parentRef={ref}>
            <DialogTitle>Dialog Title</DialogTitle>
            <DialogContent>
              Lorum Ipsum text for the dialog shall go here.
            </DialogContent>
            <DialogFooter>
              <Button variant='flat'>Action 2</Button>
              <Button>Action 1</Button>
            </DialogFooter>
          </Dialog>
        </DialogTrigger>
      </div>
    );
  },
};

export const LocalPortal: Story = {
  render: () => {
    const parentRef = useRef(null);

    return (
      <div className='flex h-[600px] w-[960px] outline outline-info-bold'>
        <div className='w-full p-l'>
          <DialogTrigger>
            <Button>Press Me</Button>
            <Dialog parentRef={parentRef}>
              <DialogTitle>Dialog Title</DialogTitle>
              <DialogContent>
                Lorum Ipsum text for the dialog shall go here.
              </DialogContent>
              <DialogFooter>
                <Button variant='flat'>Action 2</Button>
                <Button>Action 1</Button>
              </DialogFooter>
            </Dialog>
          </DialogTrigger>
        </div>
        <div
          ref={parentRef}
          className='relative h-full w-[500px] bg-info-bold'
        />
      </div>
    );
  },
};

export const Controlled: Story = {
  render: () => {
    const [open, setOpen] = useState(false);
    const handleOpenChange = (isOpen: boolean) => setOpen(isOpen);
    const handleOpenPress = useCallback(() => setOpen(true), []);

    return (
      <div className='h-[800px] w-[600px] p-l outline outline-info-bold'>
        <DialogTrigger isOpen={open} onOpenChange={handleOpenChange}>
          <Button isDisabled>Disabled</Button>
          <Dialog>
            <DialogTitle>Dialog Title</DialogTitle>
            <DialogContent>
              Lorum Ipsum text for the dialog shall go here.
            </DialogContent>
            <DialogFooter>
              <Button variant='flat'>Action 2</Button>
              <Button>Action 1</Button>
            </DialogFooter>
          </Dialog>
        </DialogTrigger>
        <Button onPress={handleOpenPress}>Press Me</Button>
      </div>
    );
  },
};
