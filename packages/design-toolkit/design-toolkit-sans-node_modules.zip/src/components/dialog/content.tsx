/*
 * Copyright 2025 Hypergiant Galactic Systems Inc. All rights reserved.
 * This file is licensed to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 * OF ANY KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
'use client';

import 'client-only';
import { clsx } from '@accelint/design-foundation/lib/utils';
import styles from './styles.module.css';
import type { ComponentProps } from 'react';

/**
 * DialogContent - Wrapper for the main dialog content.
 *
 * Provides appropriate spacing and styling for dialog body content.
 *
 * @param props - The dialog content props.
 * @param props.children - Content to display in the dialog body.
 * @param props.className - Additional CSS class name.
 * @returns The dialog content component.
 *
 * @example
 * ```tsx
 * <Dialog>
 *   <DialogTitle>Title</DialogTitle>
 *   <DialogContent>
 *     <p>Your content goes here...</p>
 *   </DialogContent>
 * </Dialog>
 * ```
 */
export function DialogContent({ children, className }: ComponentProps<'div'>) {
  return <div className={clsx(styles.content, className)}>{children}</div>;
}
