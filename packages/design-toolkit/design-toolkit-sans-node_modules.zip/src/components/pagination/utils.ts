// __private-exports
/*
 * Copyright 2025 Hypergiant Galactic Systems Inc. All rights reserved.
 * This file is licensed to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 * OF ANY KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */

const DEFAULT_EMPTY_RANGE = 0;
const DEFAULT_MIN_RANGE = 1;
const DEFAULT_MAX_RANGE = 5;
const DEFAULT_MID_RANGE = 2;
const DEFAULT_UPPER_MID = 4;

/**
 * Creates an array of numbers from start to end (inclusive).
 *
 * @example
 * ```tsx
 * range(1, 5) // [1, 2, 3, 4, 5]
 * range(3, 7) // [3, 4, 5, 6, 7]
 * ```
 *
 * @param start - The starting number of the range.
 * @param end - The ending number of the range (inclusive).
 * @returns An array of sequential numbers from start to end.
 */
export function range(start: number, end: number) {
  const length = end - start + 1;
  return Array.from({ length }, (_, index) => index + start);
}

/**
 * Checks if navigation should be disabled based on page bounds.
 *
 * @example
 * ```tsx
 * isNavigationDisabled(10, 5) // false - valid navigation
 * isNavigationDisabled(0, 1)  // true - no pages
 * isNavigationDisabled(5, 10) // true - current page exceeds total
 * ```
 *
 * @param pageCount - Total number of pages.
 * @param currentPage - Current page number.
 * @returns True if pageCount or currentPage are invalid or out of bounds.
 */
export function isNavigationDisabled(
  pageCount: number,
  currentPage: number,
): boolean {
  return (
    !pageCount || pageCount < 1 || currentPage < 1 || pageCount < currentPage
  );
}

/**
 * Return min max range for visible pages. As per our design, we limit
 * the range of numbers to a spread of 5 maximum, getting the lower and upper bounds.
 *
 * @example
 * ```tsx
 * getPaginationRange(10, 1)  // { minRange: 1, maxRange: 5 }
 * getPaginationRange(10, 5)  // { minRange: 3, maxRange: 7 }
 * getPaginationRange(10, 10) // { minRange: 6, maxRange: 10 }
 * getPaginationRange(3, 2)   // { minRange: 1, maxRange: 3 }
 * ```
 *
 * @param pageCount - total page count
 * @param currentPage - current page
 * @returns - Range of 1 to 5 numbers.
 */
export function getPaginationRange(pageCount: number, currentPage: number) {
  if (
    !(pageCount && currentPage) ||
    currentPage > pageCount ||
    pageCount < 1 ||
    currentPage < 1
  ) {
    return { minRange: DEFAULT_EMPTY_RANGE, maxRange: DEFAULT_EMPTY_RANGE };
  }

  // Below max display.
  if (pageCount < DEFAULT_MAX_RANGE) {
    return {
      minRange: DEFAULT_MIN_RANGE,
      maxRange: pageCount,
    };
  }

  // Middle.
  if (currentPage >= 3 && currentPage < pageCount - 2) {
    return {
      minRange: currentPage - DEFAULT_MID_RANGE,
      maxRange: currentPage + DEFAULT_MID_RANGE,
    };
  }

  // End of page count.
  if (currentPage > pageCount - 3) {
    return {
      minRange: pageCount - DEFAULT_UPPER_MID,
      maxRange: pageCount,
    };
  }

  return { minRange: DEFAULT_MIN_RANGE, maxRange: DEFAULT_MAX_RANGE };
}
