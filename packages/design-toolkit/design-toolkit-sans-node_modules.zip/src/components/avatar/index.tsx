/*
 * Copyright 2025 Hypergiant Galactic Systems Inc. All rights reserved.
 * This file is licensed to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 * OF ANY KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
'use client';

import 'client-only';
import { clsx } from '@accelint/design-foundation/lib/utils';
import { designTokens } from '@accelint/design-foundation/tokens';
import Person from '@accelint/icons/person';
import { Fallback, Image, Root } from '@radix-ui/react-avatar';
import { useContextProps } from 'react-aria-components';
import { BadgeProvider } from '../badge/context';
import { Icon } from '../icon';
import { IconProvider } from '../icon/context';
import { AvatarContext } from './context';
import styles from './styles.module.css';
import type { AvatarProps } from './types';

/**
 * Displays a user's profile image with automatic fallback support.
 * Built on Radix UI Avatar.
 *
 * @param props - The avatar props.
 * @param props.ref - Reference to the root span element.
 * @param props.children - Optional content such as a Badge to overlay on the avatar.
 * @param props.classNames - Custom class names for avatar sub-elements.
 * @param props.fallbackProps - Props passed to the fallback element.
 * @param props.imageProps - Props passed to the image element.
 * @param props.size - Size variant ('medium' or 'small').
 * @returns The avatar component.
 *
 * @example
 * ```tsx
 * <Avatar imageProps={{ src: "/user.jpg", alt: "User Name" }} />
 * ```
 *
 * @example
 * ```tsx
 * // With initials fallback
 * <Avatar
 *   size="small"
 *   imageProps={{ src: "/user.jpg", alt: "User Name" }}
 *   fallbackProps={{ children: "UN" }}
 * />
 * ```
 *
 * @example
 * ```tsx
 * // With status badge
 * <Avatar imageProps={{ src: "/user.jpg", alt: "User Name" }}>
 *   <Badge color="critical">3</Badge>
 * </Avatar>
 * ```
 */
export function Avatar({ ref, ...props }: AvatarProps) {
  [props, ref] = useContextProps(props, ref ?? null, AvatarContext);

  const {
    children,
    classNames,
    fallbackProps,
    imageProps,
    size = 'medium',
    ...rest
  } = props;

  return (
    <IconProvider size={size === 'medium' ? 'large' : 'medium'}>
      <Root
        {...rest}
        ref={ref}
        className={clsx('group/avatar', styles.avatar, classNames?.avatar)}
        role='img'
        data-size={size}
      >
        <Image
          {...imageProps}
          className={clsx(styles.image, classNames?.image)}
        />
        <Fallback
          {...fallbackProps}
          className={clsx(styles.fallback, classNames?.fallback)}
        >
          {fallbackProps?.children || (
            <Icon>
              <Person />
            </Icon>
          )}
        </Fallback>
        <BadgeProvider offset={designTokens.spacing.xs} placement='top right'>
          <span className={clsx(styles.content, classNames?.content)}>
            {children}
          </span>
        </BadgeProvider>
      </Root>
    </IconProvider>
  );
}
