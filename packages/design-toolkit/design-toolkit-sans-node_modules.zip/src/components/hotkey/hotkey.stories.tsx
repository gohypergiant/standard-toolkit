/*
 * Copyright 2025 Hypergiant Galactic Systems Inc. All rights reserved.
 * This file is licensed to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 * OF ANY KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */

import MouseRightClick from '@accelint/icons/mouse-right-click';
import { Icon } from '../icon';
import { Hotkey } from './';
import { HotkeySet } from './set';
import type { Meta, StoryObj } from '@storybook/react-vite';

const meta = {
  title: 'Components/Hotkey',
  component: Hotkey,
} satisfies Meta<typeof Hotkey>;

export default meta;

export const Default: StoryObj<typeof meta> = {
  args: {
    children: 'ctrl',
    variant: 'outline',
  },
  argTypes: {
    variant: {
      control: 'select',
      options: ['outline', 'flat', 'icon'],
    },
  },
  render: ({ children, variant }) => {
    return (
      <div className='flex flex-col gap-xl'>
        <Hotkey variant={variant}>
          {variant === 'icon' ? (
            <Icon>
              <MouseRightClick />
            </Icon>
          ) : (
            children
          )}
        </Hotkey>
      </div>
    );
  },
};

export const KeysSet: StoryObj<typeof meta> = {
  render: () => {
    return (
      <div className='flex flex-col gap-xl'>
        <HotkeySet>
          <Hotkey>CMD</Hotkey>
          <span>+</span>
          <Hotkey variant='icon'>
            <Icon>
              <MouseRightClick />
            </Icon>
          </Hotkey>
          <span>+</span>
          <Hotkey>⌘V</Hotkey>
        </HotkeySet>
        <HotkeySet>
          <Hotkey>CMD</Hotkey>
          <span>or</span>
          <Hotkey variant='icon'>
            <Icon>
              <MouseRightClick />
            </Icon>
          </Hotkey>
          <span>+</span>
          <Hotkey>⌘V</Hotkey>
        </HotkeySet>
      </div>
    );
  },
};
