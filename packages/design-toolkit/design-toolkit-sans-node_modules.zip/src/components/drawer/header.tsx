/*
 * Copyright 2025 Hypergiant Galactic Systems Inc. All rights reserved.
 * This file is licensed to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 * OF ANY KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
'use client';

import { clsx } from '@accelint/design-foundation/lib/utils';
import { Cancel } from '@accelint/icons';
import 'client-only';
import { type ComponentPropsWithRef, useContext } from 'react';
import { Header } from 'react-aria-components';
import { Button } from '../button';
import { Icon } from '../icon';
import { ViewStackContext } from '../view-stack/context';
import { DrawerBack } from './back';
import { DrawerHeaderTitle } from './header-title';
import styles from './styles.module.css';
import { DrawerTrigger } from './trigger';

/**
 * DrawerHeader - Header region within a DrawerView.
 *
 * Supports two usage patterns:
 * - Use `title` prop for automatic layout with back/close buttons
 * - Use `children` for custom header content
 *
 * Heading level automatically adjusts based on view stack depth
 * (h2 for root view, h4 for nested views).
 *
 * @param props - ComponentPropsWithRef<'header'>
 * @param props.className - Optional CSS class name.
 * @param props.title - Title text for the header.
 * @param props.children - Custom header content (overrides title).
 * @returns The rendered DrawerHeader component.
 *
 * @example
 * ```tsx
 * // Simplified with title prop
 * <DrawerHeader title="Settings" />
 * ```
 *
 * @example
 * ```tsx
 * // Custom layout
 * <DrawerHeader>
 *   <DrawerHeaderTitle level={2}>Settings</DrawerHeaderTitle>
 *   <DrawerClose />
 * </DrawerHeader>
 *```
 */
export function DrawerHeader({
  className,
  title,
  children,
  ...rest
}: ComponentPropsWithRef<'header'>) {
  const { stack } = useContext(ViewStackContext);
  const level = stack.length > 1 ? 4 : 2;

  return (
    <Header {...rest} className={clsx(styles.header, className)}>
      {children == null ? (
        <>
          <DrawerBack />
          <DrawerHeaderTitle level={level}>{title}</DrawerHeaderTitle>
          <DrawerTrigger for='clear'>
            <Button variant='icon'>
              <Icon>
                <Cancel />
              </Icon>
            </Button>
          </DrawerTrigger>
        </>
      ) : (
        children
      )}
    </Header>
  );
}
