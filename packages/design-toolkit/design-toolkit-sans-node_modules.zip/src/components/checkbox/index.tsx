/*
 * Copyright 2025 Hypergiant Galactic Systems Inc. All rights reserved.
 * This file is licensed to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 * OF ANY KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
'use client';
import 'client-only';
import { clsx } from '@accelint/design-foundation/lib/utils';
import Check from '@accelint/icons/check';
import Remove from '@accelint/icons/remove';
import {
  Checkbox as AriaCheckbox,
  composeRenderProps,
  useContextProps,
} from 'react-aria-components';
import { Icon } from '../icon';
import { CheckboxContext } from './context';
import styles from './styles.module.css';
import type { CheckboxProps } from './types';

/**
 * Checkbox - A form control for binary or multiple selection with group support
 *
 * Provides accessible checkbox functionality with support for individual checkboxes
 * or grouped selections. Includes visual feedback for checked, indeterminate, and
 * disabled states with integrated labeling and validation support.
 *
 * @param props - The checkbox props.
 * @param props.ref - Reference to the label element.
 * @param props.classNames - Custom class names for sub-elements.
 * @param props.children - Label content for the checkbox.
 * @param props.isSelected - Whether the checkbox is checked.
 * @param props.isIndeterminate - Whether the checkbox is in indeterminate state.
 * @param props.isDisabled - Whether the checkbox is disabled.
 * @returns The checkbox component.
 *
 * @example
 * ```tsx
 * // Basic checkbox
 * <Checkbox>
 *   Accept terms and conditions
 * </Checkbox>
 * ```
 *
 * @example
 * ```tsx
 * // Checkbox group with multiple options
 * <CheckboxGroup label="Select preferences">
 *   <Checkbox value="notifications">Email notifications</Checkbox>
 *   <Checkbox value="marketing">Marketing emails</Checkbox>
 *   <Checkbox value="updates">Product updates</Checkbox>
 * </CheckboxGroup>
 * ```
 *
 * @example
 * ```tsx
 * // Disabled checkbox
 * <Checkbox isDisabled>
 *   Unavailable option
 * </Checkbox>
 * ```
 *
 * @example
 * ```tsx
 * // Indeterminate checkbox (partial selection)
 * <Checkbox isIndeterminate>
 *   Select all items
 * </Checkbox>
 * ```
 */
export function Checkbox({ ref, ...props }: CheckboxProps) {
  [props, ref] = useContextProps(props, ref ?? null, CheckboxContext);

  const { classNames, children, ...rest } = props;

  return (
    <AriaCheckbox
      {...rest}
      ref={ref}
      className={composeRenderProps(classNames?.checkbox, (className) =>
        clsx('group/checkbox', styles.checkbox, className),
      )}
    >
      {composeRenderProps(
        children,
        (children, { isIndeterminate, isSelected }) => (
          <>
            <span className={clsx(styles.control, classNames?.control)}>
              <Icon size='small'>
                {isIndeterminate && !isSelected && <Remove />}
                {isSelected && <Check />}
              </Icon>
            </span>
            {children && (
              <span className={clsx(styles.label, classNames?.label)}>
                {children}
              </span>
            )}
          </>
        ),
      )}
    </AriaCheckbox>
  );
}
