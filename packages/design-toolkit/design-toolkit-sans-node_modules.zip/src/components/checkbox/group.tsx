/*
 * Copyright 2025 Hypergiant Galactic Systems Inc. All rights reserved.
 * This file is licensed to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 * OF ANY KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
'use client';

import 'client-only';
import { clsx } from '@accelint/design-foundation/lib/utils';
import {
  CheckboxGroup as AriaCheckboxGroup,
  composeRenderProps,
  useContextProps,
} from 'react-aria-components';
import { Label } from '../label';
import { CheckboxGroupContext } from './context';
import styles from './styles.module.css';
import type { CheckboxGroupProps } from './types';

/**
 * Groups multiple checkboxes with shared state and configuration.
 *
 * @param props - The checkbox group props.
 * @param props.ref - Reference to the group container element.
 * @param props.children - Checkbox components to render within the group.
 * @param props.classNames - Custom class names for sub-elements.
 * @param props.label - Label text displayed above the group.
 * @param props.orientation - Layout orientation ('vertical' or 'horizontal').
 * @returns The checkbox group component.
 *
 * @example
 * ```tsx
 * <CheckboxGroup label="Preferences">
 *   <Checkbox value="email">Email</Checkbox>
 *   <Checkbox value="sms">SMS</Checkbox>
 * </CheckboxGroup>
 * ```
 *
 * @example
 * ```tsx
 * // Horizontal layout
 * <CheckboxGroup label="Features" orientation="horizontal">
 *   <Checkbox value="a">Feature A</Checkbox>
 *   <Checkbox value="b">Feature B</Checkbox>
 * </CheckboxGroup>
 * ```
 */
export function CheckboxGroup({ ref, ...props }: CheckboxGroupProps) {
  [props, ref] = useContextProps(props, ref ?? null, CheckboxGroupContext);

  const {
    children,
    classNames,
    label,
    orientation = 'vertical',
    ...rest
  } = props;

  return (
    <AriaCheckboxGroup
      {...rest}
      ref={ref}
      className={composeRenderProps(classNames?.group, (className) =>
        clsx('group/checkbox-group', styles.group, className),
      )}
      data-orientation={orientation}
    >
      {composeRenderProps(children, (children, { isDisabled, isRequired }) => (
        <>
          {label && (
            <Label
              className={clsx(styles.label, classNames?.label)}
              isDisabled={isDisabled}
              isRequired={isRequired}
            >
              {label}
            </Label>
          )}
          {children}
        </>
      ))}
    </AriaCheckboxGroup>
  );
}
