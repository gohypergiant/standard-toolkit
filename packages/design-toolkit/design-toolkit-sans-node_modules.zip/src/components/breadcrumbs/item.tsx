/*
 * Copyright 2025 Hypergiant Galactic Systems Inc. All rights reserved.
 * This file is licensed to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 * OF ANY KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
'use client';

import 'client-only';
import { clsx } from '@accelint/design-foundation/lib/utils';
import ChevronRight from '@accelint/icons/chevron-right';
import { Breadcrumb, composeRenderProps, Link } from 'react-aria-components';
import { Icon } from '../icon';
import styles from './styles.module.css';
import type { BreadcrumbItemProps } from './types';

/**
 * Individual breadcrumb item. Renders as a link when `linkProps` is provided,
 * or as plain text for the current page.
 *
 * @param props - The breadcrumb item props.
 * @param props.children - Content to display in the breadcrumb.
 * @param props.classNames - Custom class names for sub-elements.
 * @param props.linkProps - Props for the Link component (omit for current page).
 * @returns The breadcrumb item component.
 *
 * @example
 * ```tsx
 * // Link item
 * <BreadcrumbItem linkProps={{ href: '/home' }}>Home</BreadcrumbItem>
 * ```
 *
 * @example
 * ```tsx
 * // Current page (no link)
 * <BreadcrumbItem>Current Page</BreadcrumbItem>
 * ```
 */
export function BreadcrumbItem({
  children,
  classNames,
  linkProps,
  ...rest
}: BreadcrumbItemProps) {
  return (
    <Breadcrumb
      {...rest}
      className={composeRenderProps(classNames?.item, (className) =>
        clsx('group/breadcrumb', styles.item, className),
      )}
    >
      {composeRenderProps(linkProps ? null : children, (itemChildren) => (
        <>
          {linkProps ? (
            <Link
              {...linkProps}
              className={composeRenderProps(classNames?.link, (className) =>
                clsx(styles.link, className),
              )}
            >
              {children}
            </Link>
          ) : (
            itemChildren
          )}
          <Icon
            aria-hidden='true'
            className={clsx(styles.separator, classNames?.separator)}
          >
            <ChevronRight />
          </Icon>
        </>
      ))}
    </Breadcrumb>
  );
}
