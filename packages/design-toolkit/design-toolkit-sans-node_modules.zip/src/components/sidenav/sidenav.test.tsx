/*
 * Copyright 2025 Hypergiant Galactic Systems Inc. All rights reserved.
 * This file is licensed to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 * OF ANY KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */

import { uuid } from '@accelint/core';
import { Placeholder } from '@accelint/icons';
import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { Heading, Text } from 'react-aria-components';
import { describe, expect, it } from 'vitest';
import { Button } from '../button';
import { Divider } from '../divider';
import { Icon } from '../icon';
import { Sidenav } from './';
import { SidenavAvatar } from './avatar';
import { SidenavContent } from './content';
import { SidenavFooter } from './footer';
import { SidenavHeader } from './header';
import { SidenavItem } from './item';
import { SidenavLink } from './link';
import { SidenavMenu } from './menu';
import { SidenavMenuItem } from './menu-item';
import { SidenavTrigger } from './trigger';
import type { ReactNode } from 'react';
import type { SidenavProps } from './types';

const id = uuid();

function setup(
  {
    children = (
      <>
        <SidenavHeader>
          <SidenavAvatar>
            <Icon data-testid='logo'>
              <Placeholder />
            </Icon>
            <Heading>Application Header</Heading>
            <Text>subheader</Text>
          </SidenavAvatar>
        </SidenavHeader>
        <SidenavContent>
          <Heading>Title</Heading>
          <SidenavItem>
            <Icon>
              <Placeholder />
            </Icon>
            <Text>Nav item</Text>
          </SidenavItem>
          <Divider />
          <Heading>External</Heading>
          <SidenavLink href='#' textValue='Link item'>
            <Icon>
              <Placeholder />
            </Icon>
            <Text>Link item</Text>
          </SidenavLink>
          <Divider />
          <Heading>Menu</Heading>
          <SidenavMenu
            data-testid='menu'
            icon={
              <Icon>
                <Placeholder />
              </Icon>
            }
            title='Settings'
          >
            <SidenavMenuItem>
              <Text>Menu Item</Text>
            </SidenavMenuItem>
            <SidenavMenuItem>
              <Text>Menu Item 2</Text>
            </SidenavMenuItem>
          </SidenavMenu>
        </SidenavContent>
        <SidenavFooter>
          <SidenavAvatar>
            <Icon data-testid='avatar'>
              <Placeholder />
            </Icon>
            <Heading>FullName</Heading>
            <Text>test@example.com</Text>
          </SidenavAvatar>
        </SidenavFooter>
      </>
    ),
    ...rest
  }: Partial<SidenavProps> = {},
  outside: ReactNode = (
    <SidenavTrigger for={id}>
      <Button>Open</Button>
    </SidenavTrigger>
  ),
) {
  return {
    ...render(
      <>
        <Sidenav {...rest} id={id} data-testid='nav'>
          {children}
        </Sidenav>
        {outside}
      </>,
    ),
    ...rest,
    children,
  };
}

describe('Sidenav', () => {
  it('should not render expanded content', async () => {
    setup();
    screen.debug();
    expect(
      screen.getByText('Application Header').classList.toString(),
    ).includes('transient');
    expect(screen.getByText('subheader').classList.toString()).includes(
      'transient',
    );
    expect(screen.getByText('Title').classList.toString()).includes(
      'transient',
    );
    expect(screen.getByText('Nav item').classList.toString()).includes(
      'transient',
    );
    expect(screen.getByText('External').classList.toString()).includes(
      'transient',
    );
    expect(screen.getByText('Link item').classList.toString()).includes(
      'transient',
    );
    expect(screen.getByTestId('menu')).toBeInTheDocument();
    expect(screen.getByText('FullName').classList.toString()).includes(
      'transient',
    );
    expect(screen.getByText('test@example.com').classList.toString()).includes(
      'transient',
    );

    expect(screen.queryByText('Settings')).not.toBeInTheDocument();
    expect(screen.queryByText('Menu Item')).not.toBeInTheDocument();
    expect(screen.queryByText('Menu Item 2')).not.toBeInTheDocument();

    await userEvent.click(screen.getByTestId('menu'));

    expect(screen.getByText('Settings')).toBeInTheDocument();
    expect(screen.getByText('Menu Item')).toBeInTheDocument();
    expect(screen.getByText('Menu Item 2')).toBeInTheDocument();
  });

  it('should open externally', async () => {
    setup();

    await userEvent.click(screen.getByText('Open'));

    expect(screen.getByTestId('nav')).toHaveAttribute('data-open', 'true');
  });

  it('should close externally', async () => {
    setup();

    await userEvent.click(screen.getByText('Open'));

    expect(screen.getByTestId('nav')).toHaveAttribute('data-open', 'true');

    await userEvent.click(screen.getByText('Open'));

    expect(screen.getByTestId('nav')).not.toHaveAttribute('data-open');
  });

  it('should open internally', async () => {
    setup();

    await userEvent.click(screen.getByTestId('logo'));

    expect(screen.getByTestId('nav')).toHaveAttribute('data-open', 'true');
  });

  it('should close internally', async () => {
    setup();

    await userEvent.click(screen.getByTestId('logo'));

    expect(screen.getByTestId('nav')).toHaveAttribute('data-open', 'true');

    await userEvent.click(screen.getByTestId('logo'));

    expect(screen.getByTestId('nav')).not.toHaveAttribute('data-open');
  });
});
