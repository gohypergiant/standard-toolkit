/*
 * Copyright 2025 Hypergiant Galactic Systems Inc. All rights reserved.
 * This file is licensed to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 * OF ANY KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
'use client';

import { Cache } from '@/hooks/use-tree/actions/cache';
import type { Key, Selection } from '@react-types/shared';
import 'client-only';
import { clsx } from '@accelint/design-foundation/lib/utils';
import { useMemo } from 'react';
import {
  Tree as AriaTree,
  composeRenderProps,
  DropIndicator,
  type DropTarget,
  useDragAndDrop,
} from 'react-aria-components';
import { TreeContext } from './context';
import styles from './styles.module.css';
import type { TreeProps } from './types';

const defaultRenderDropIndicator = (target: DropTarget) => (
  <DropIndicator target={target} className={styles.dropIndicator} />
);

/**
 * Tree - Hierarchical tree view with selection, visibility, and drag-and-drop
 *
 * Supports static or dynamic collections with keyboard navigation and accessibility.
 *
 * @param props - {@link TreeProps}
 * @param props.children - Tree items or render function for dynamic collections.
 * @param props.className - CSS class for the tree container.
 * @param props.disabledKeys - Set of disabled item keys.
 * @param props.dragAndDropConfig - Configuration for drag and drop behavior.
 * @param props.expandedKeys - Set of expanded item keys.
 * @param props.items - Data source for dynamic collections.
 * @param props.selectedKeys - Set of selected item keys.
 * @param props.showRuleLines - Whether to show connecting lines between items.
 * @param props.showVisibility - Whether to show visibility toggle buttons.
 * @param props.selectionMode - Selection mode for the tree.
 * @param props.variant - Visual density variant.
 * @param props.visibleKeys - Set of visible item keys.
 * @param props.onVisibilityChange - Callback when item visibility changes.
 * @param props.onSelectionChange - Callback when selection changes.
 * @returns The rendered Tree component.
 *
 * @example
 * // Dynamic collection
 * ```tsx
 * <Tree items={items} expandedKeys={expandedKeys}>
 *   {(node) => <TreeItem key={node.key}>{node.label}</TreeItem>}
 * </Tree>
 * ```
 *
 * @example
 * ```tsx
 * // Static collection
 * <Tree>
 *   <TreeItem id="one" textValue="one">
 *     <TreeItemContent>One</TreeItemContent>
 *     <TreeItem id="two" textValue="two">
 *       <TreeItemContent>Two</TreeItemContent>
 *     </TreeItem>
 *   </TreeItem>
 * </Tree>
 * ```
 */
export function Tree<T>({
  children,
  className,
  disabledKeys: disabledKeysProp,
  dragAndDropConfig,
  expandedKeys: expandedKeysProp,
  items,
  selectedKeys: selectedKeysProp,
  showRuleLines = true,
  showVisibility = true,
  selectionMode = 'multiple',
  variant = 'cozy',
  visibleKeys: visibleKeysProp,
  onVisibilityChange,
  onSelectionChange,
  ...rest
}: TreeProps<T>) {
  /**
   * A static collection is hard-coded. Dynamic is data-driven from an external source.
   * https://react-spectrum.adobe.com/react-aria/Tree.html#content
   *
   * Controlled state should only be used on a static tree.
   */
  if (
    items &&
    (disabledKeysProp ||
      expandedKeysProp ||
      selectedKeysProp ||
      visibleKeysProp)
  ) {
    throw new Error(
      'Tree should only be controlled with state from either `items` or keys props, not both',
    );
  }

  /**
   * A static tree won't support the node iterator pattern.
   */
  if (!!items !== (typeof children === 'function')) {
    throw new Error(
      'Tree `items` and node iterator `children` must be used together',
    );
  }

  const { dragAndDropHooks } = useDragAndDrop({
    renderDropIndicator: defaultRenderDropIndicator,
    getAllowedDropOperations: () => ['move'],
    getDropOperation: () => 'move',
    ...dragAndDropConfig,
  });
  const cache = useMemo(() => (items ? new Cache([...items]) : null), [items]);
  const nodes = useMemo(() => cache?.getAllNodes(), [cache]);
  const {
    disabledKeys,
    expandedKeys,
    selectedKeys,
    visibleKeys,
    visibilityComputedKeys,
  } = useMemo(() => {
    const acc = {
      disabledKeys: nodes ? new Set<Key>() : disabledKeysProp,
      expandedKeys: nodes ? new Set<Key>() : expandedKeysProp,
      selectedKeys: nodes ? new Set<Key>() : selectedKeysProp,
      visibleKeys: nodes ? new Set<Key>() : visibleKeysProp,
      visibilityComputedKeys: new Set<Key>(),
    };

    if (!nodes) {
      return acc;
    }

    return nodes.reduce(
      (
        acc,
        {
          key,
          isDisabled,
          isExpanded,
          isSelected,
          isVisible,
          isVisibleComputed,
        },
      ) => {
        if (isDisabled) {
          acc.disabledKeys?.add(key);
        }
        if (isExpanded) {
          acc.expandedKeys?.add(key);
        }
        if (isSelected) {
          acc.selectedKeys?.add(key);
        }
        if (isVisible) {
          acc.visibleKeys?.add(key);
        }
        if (isVisibleComputed) {
          acc.visibilityComputedKeys.add(key);
        }
        return acc;
      },
      acc,
    );
  }, [
    nodes,
    disabledKeysProp,
    expandedKeysProp,
    selectedKeysProp,
    visibleKeysProp,
  ]);

  const handleSelectionChange = selectedKeys
    ? (selection: Selection) => {
        if (selection !== 'all') {
          onSelectionChange?.(selection);
        }
      }
    : undefined;

  return (
    <TreeContext.Provider
      value={{
        disabledKeys,
        expandedKeys,
        selectedKeys,
        showRuleLines,
        showVisibility,
        variant,
        visibleKeys,
        visibilityComputedKeys,
        isStatic: typeof children !== 'function',
        onVisibilityChange: onVisibilityChange ?? (() => undefined), // TODO: improve
      }}
    >
      <AriaTree
        {...rest}
        className={composeRenderProps(className, (className) =>
          clsx(styles.tree, className),
        )}
        disabledKeys={disabledKeys}
        dragAndDropHooks={dragAndDropHooks}
        expandedKeys={expandedKeys}
        items={items}
        selectedKeys={selectedKeys}
        onSelectionChange={handleSelectionChange}
        selectionMode={selectionMode}
      >
        {children}
      </AriaTree>
    </TreeContext.Provider>
  );
}
