/*
 * Copyright 2025 Hypergiant Galactic Systems Inc. All rights reserved.
 * This file is licensed to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 * OF ANY KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */

import { clsx } from '@accelint/design-foundation/lib/utils';
import ChevronDown from '@accelint/icons/chevron-down';
import ChevronUp from '@accelint/icons/chevron-up';
import DragVert from '@accelint/icons/drag-vert';
import Hide from '@accelint/icons/hide';
import Show from '@accelint/icons/show';
import { useContext } from 'react';
import { TreeItemContent as AriaTreeItemContent } from 'react-aria-components';
import { Button } from '../button';
import { Checkbox } from '../checkbox';
import { Icon } from '../icon';
import { IconProvider } from '../icon/context';
import { TreeContext, TreeItemContext } from './context';
import { TreeLines } from './lines';
import styles from './styles.module.css';
import type { Key } from '@react-types/shared';
import type { TreeItemContentProps } from './types';

/**
 * TreeItemContent - Renders the display content of a tree node
 *
 * @example
 * ```tsx
 * <TreeItem id="node" textValue="Node">
 *   <TreeItemContent>
 *     <TreeItemPrefixIcon><Folder /></TreeItemPrefixIcon>
 *     <TreeItemLabel>Folder Name</TreeItemLabel>
 *     <TreeItemDescription>Contains 5 items</TreeItemDescription>
 *   </TreeItemContent>
 * </TreeItem>
 * ```
 *
 * @param props - {@link TreeItemContentProps}
 * @param props.children - Content to render, or a render function receiving TreeItemContentRenderProps.
 * @returns The rendered TreeItemContent component.
 */
export function TreeItemContent({ children }: TreeItemContentProps) {
  const { showVisibility, variant, visibleKeys, onVisibilityChange } =
    useContext(TreeContext);
  const { isVisible, isViewable } = useContext(TreeItemContext);
  const size = variant === 'cozy' ? 'medium' : 'small';

  return (
    <AriaTreeItemContent>
      {(renderProps) => {
        const {
          id,
          allowsDragging,
          hasChildItems,
          level,
          selectionBehavior,
          selectionMode,
          state,
          isDisabled,
          isExpanded,
          isSelected,
        } = renderProps;

        const isLastOfSet = !(
          state.collection.getItem(id)?.nextKey || hasChildItems
        );
        const shouldShowSelection =
          selectionBehavior === 'toggle' && selectionMode !== 'none';

        const handlePress = () => {
          const keys = new Set<Key>(visibleKeys);
          visibleKeys?.has(id) ? keys.delete(id) : keys.add(id);
          onVisibilityChange?.(keys);
        };

        return (
          <IconProvider size={size}>
            <div
              className={clsx('group', styles.content, styles[variant])}
              data-last-of-set={isLastOfSet}
            >
              {showVisibility && (
                <Button
                  variant='icon'
                  color='mono-bold'
                  size={size}
                  onPress={handlePress}
                  isDisabled={isDisabled}
                  className={styles.visibility}
                >
                  <Icon>{isVisible ? <Show /> : <Hide />}</Icon>
                </Button>
              )}
              {level > 1 && (
                <TreeLines level={level} isLastOfSet={isLastOfSet} />
              )}
              {hasChildItems ? (
                <Button
                  slot='chevron'
                  variant='icon'
                  size={size}
                  className={styles.expansion}
                >
                  <Icon>{isExpanded ? <ChevronDown /> : <ChevronUp />}</Icon>
                </Button>
              ) : (
                <div className={clsx(styles.spacing, styles[variant])} />
              )}
              <div className={clsx(styles.display, styles[variant])}>
                {typeof children === 'function'
                  ? children({
                      ...renderProps,
                      variant,
                      isVisible,
                      isViewable: isViewable,
                      defaultChildren: null,
                    })
                  : children}
              </div>
              {shouldShowSelection && (
                <Checkbox
                  slot='selection'
                  isSelected={isSelected}
                  isDisabled={isDisabled}
                />
              )}
              {allowsDragging && (
                <Button
                  slot='drag'
                  variant='icon'
                  size={size}
                  isDisabled={isDisabled}
                  className={styles.drag}
                >
                  <Icon>
                    <DragVert />
                  </Icon>
                </Button>
              )}
            </div>
          </IconProvider>
        );
      }}
    </AriaTreeItemContent>
  );
}
