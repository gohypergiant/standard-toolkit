/*
 * Copyright 2025 Hypergiant Galactic Systems Inc. All rights reserved.
 * This file is licensed to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 * OF ANY KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */

'use client';

import 'client-only';
import { clsx } from '@accelint/design-foundation/lib/utils';
import {
  TabList as AriaTabList,
  composeRenderProps,
  type TabListProps,
} from 'react-aria-components';
import styles from './styles.module.css';

/**
 * TabList - Container for Tab components.
 *
 * @example
 * ```tsx
 * <Tabs>
 *   <TabList>
 *     <Tab id="profile">Profile</Tab>
 *     <Tab id="settings">Settings</Tab>
 *   </TabList>
 *   <TabPanel id="profile">Profile content</TabPanel>
 *   <TabPanel id="settings">Settings content</TabPanel>
 * </Tabs>
 * ```
 *
 * @param props - TabListProps from react-aria-components.
 * @param props.children - Tab components to render.
 * @param props.className - CSS class for the tab list.
 * @returns The rendered TabList component.
 */
export function TabList<T extends object>({
  children,
  className,
  ...rest
}: TabListProps<T>) {
  return (
    <AriaTabList<T>
      {...rest}
      className={composeRenderProps(className, (className) =>
        clsx(styles.list, className),
      )}
    >
      {children}
    </AriaTabList>
  );
}
