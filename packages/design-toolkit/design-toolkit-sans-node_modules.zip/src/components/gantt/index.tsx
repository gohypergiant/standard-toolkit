/*
 * Copyright 2026 Hypergiant Galactic Systems Inc. All rights reserved.
 * This file is licensed to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 * OF ANY KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */

import { TIMESCALE_MAPPING } from './constants';
import { useGanttInit } from './hooks/use-gantt-init';
import { useGanttStore } from './store';
import type { UIEvent } from 'react';
import type { Timescale } from './types';

type GanttProps = {
  startTimeMs: number;
  endTimeMs: number;
  timescale: Timescale;
};

const TIMELINE_CHUNK_WIDTH_PX = 80;

function getMsPerPx(timelineChunkPx: number, timescale: Timescale) {
  return TIMESCALE_MAPPING[timescale] / timelineChunkPx;
}

function getTotalTimelineMs(startTimeMs: number, endTimeMs: number) {
  return endTimeMs - startTimeMs;
}

function getTotalTimelineWidth(totalTimelineMs: number, msPerPx: number) {
  return totalTimelineMs / msPerPx;
}

function getScrolledPixels(event: UIEvent<HTMLDivElement>) {
  const { currentTarget } = event;

  return currentTarget.scrollLeft;
}

const updateCurrentPositionMs =
  (startTimeMs: number, msPerPx: number) => (event: UIEvent<HTMLDivElement>) =>
    useGanttStore
      .getState()
      .setCurrentPositionMs(startTimeMs + getScrolledPixels(event) * msPerPx);

export function Gantt({ startTimeMs, endTimeMs, timescale }: GanttProps) {
  useGanttInit(startTimeMs);
  const msPerPx = getMsPerPx(TIMELINE_CHUNK_WIDTH_PX, timescale);
  const width = getTotalTimelineWidth(
    getTotalTimelineMs(startTimeMs, endTimeMs),
    msPerPx,
  );

  console.log({
    startTimeMs,
    endTimeMs,
  });

  return (
    <div
      style={{ overflowX: 'scroll' }}
      onScroll={updateCurrentPositionMs(startTimeMs, msPerPx)}
    >
      <div style={{ width, overflowX: 'auto' }}>gantt</div>
    </div>
  );
}
