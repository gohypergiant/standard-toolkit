/*
 * Copyright 2025 Hypergiant Galactic Systems Inc. All rights reserved.
 * This file is licensed to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 * OF ANY KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */

import { clsx } from '@accelint/design-foundation/lib/utils';
import styles from './styles.module.css';
import type { LinesProps } from './types';

/**
 * Lines - Decorative rule/connector lines used by components like Tree
 *
 * Renders horizontal or vertical rule lines used for visual grouping and
 * tree branch connectors. Visibility and variant control the appearance.
 *
 * @param props - {@link LinesProps}
 * @param props.className - Optional CSS class name.
 * @param props.size - Size variant for the lines.
 * @param props.variant - Visual style variant for the connector line.
 * @param props.isVisible - Whether the lines are visible.
 * @returns The rendered Lines component.
 *
 * @example
 * ```tsx
 * <Lines variant="branch" />
 * ```
 */
export function Lines({
  className,
  size = 'medium',
  variant = 'branch',
  isVisible = true,
}: LinesProps) {
  return (
    <div
      className={clsx(styles.lines, styles[variant], className)}
      data-size={size}
      data-visible={isVisible || null}
    />
  );
}
