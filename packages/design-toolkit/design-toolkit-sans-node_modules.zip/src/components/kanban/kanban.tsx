/*
 * Copyright 2025 Hypergiant Galactic Systems Inc. All rights reserved.
 * This file is licensed to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 * OF ANY KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
'use client';
import 'client-only';

import { clsx } from '@accelint/design-foundation/lib/utils';
import {
  type CollisionDetection,
  closestCenter,
  DndContext,
  type DragEndEvent,
  DragOverlay,
  type DragStartEvent,
  PointerSensor,
  pointerWithin,
  rectIntersection,
  useSensor,
  useSensors,
} from '@dnd-kit/core';
import { createContext, useContext, useState } from 'react';
import { parseDropTarget, useKanban } from '@/components/kanban/context';
import styles from './styles.module.css';
import type { KanbanProps } from './types';

/**
 * Context for sharing active drag state across Kanban components.
 */
export const DragContext = createContext<{ activeId: string | null } | null>(
  null,
);

/**
 * Hook to access the active drag state.
 * Must be used within a Kanban component.
 * @returns The drag context with activeId.
 */
export const useDragContext = () => {
  const context = useContext(DragContext);
  if (!context) {
    throw new Error('useDragContext must be used within Kanban component');
  }
  return context;
};

const ACTIVATION_DISTANCE = 8;

/**
 * Kanban - Root container for the drag-and-drop kanban board
 *
 * Provides DnD context and manages drag state for cards and columns.
 * Must be wrapped in a KanbanProvider.
 *
 * @param props - {@link KanbanProps}
 * @param props.children - Child components (columns, header, etc.).
 * @param props.className - Optional CSS class name.
 * @returns The rendered Kanban component.
 *
 * @example
 * ```tsx
 * <KanbanProvider columns={columns} updateColumnState={setColumns}>
 *   <Kanban>
 *     <KanbanHeader>...</KanbanHeader>
 *     <KanbanColumnContainer>...</KanbanColumnContainer>
 *   </Kanban>
 * </KanbanProvider>
 * ```
 */
export function Kanban({ children, className, ...rest }: KanbanProps) {
  const { moveCard, cardMap } = useKanban();
  const [activeId, setActiveId] = useState<string | null>(null);

  const sensors = useSensors(
    useSensor(PointerSensor, {
      activationConstraint: {
        distance: ACTIVATION_DISTANCE,
      },
    }),
  );

  const collisionDetectionStrategy: CollisionDetection = (args) => {
    // First, try pointer within for direct pointer detection
    const pointerCollisions = pointerWithin(args);
    if (pointerCollisions.length > 0) {
      return pointerCollisions;
    }

    // Then try rectangle intersection for better coverage
    const rectCollisions = rectIntersection(args);
    if (rectCollisions.length > 0) {
      return rectCollisions;
    }

    // Fall back to closest center
    return closestCenter(args);
  };

  const handleDragStart = (event: DragStartEvent) => {
    setActiveId(event.active.id as string);
  };

  const handleDragEnd = (event: DragEndEvent) => {
    setActiveId(null);

    const dropTarget = parseDropTarget(event);
    if (!dropTarget) {
      return;
    }

    moveCard(
      event.active.id as string,
      dropTarget.columnId,
      dropTarget.position,
      dropTarget.edge,
    );
  };

  // Find the active card for the drag overlay
  const activeCard = activeId ? cardMap.get(activeId)?.card : null;

  return (
    <DragContext.Provider value={{ activeId }}>
      <DndContext
        sensors={sensors}
        collisionDetection={collisionDetectionStrategy}
        onDragStart={handleDragStart}
        onDragEnd={handleDragEnd}
      >
        <div className={clsx(styles.kanban, className)} {...rest}>
          {children}
        </div>
        <DragOverlay>
          {activeCard ? (
            <div data-current className={clsx(styles.card)}>
              <div className={styles.cardHeader}>
                <span className={styles.cardTitle}>{activeCard.title}</span>
              </div>
              <div className={styles.cardBody}>{activeCard.body}</div>
            </div>
          ) : null}
        </DragOverlay>
      </DndContext>
    </DragContext.Provider>
  );
}
