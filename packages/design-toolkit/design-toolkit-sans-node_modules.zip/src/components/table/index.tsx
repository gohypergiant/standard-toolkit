/*
 * Copyright 2025 Hypergiant Galactic Systems Inc. All rights reserved.
 * This file is licensed to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 * OF ANY KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */

'use client';
import 'client-only';
import { clsx } from '@accelint/design-foundation/lib/utils';
import Kebab from '@accelint/icons/kebab';
import Pin from '@accelint/icons/pin';
import { useListData } from '@react-stately/data';
import {
  getCoreRowModel,
  getSortedRowModel,
  type Row,
  type RowPinningState,
  type RowSelectionState,
  useReactTable,
} from '@tanstack/react-table';
import { useCallback, useContext, useMemo, useState } from 'react';
import { Button } from '../button';
import { Checkbox } from '../checkbox';
import { Icon } from '../icon';
import { Menu } from '../menu';
import { MenuItem } from '../menu/item';
import { MenuSeparator } from '../menu/separator';
import { MenuTrigger } from '../menu/trigger';
import { TableBody } from './body';
import { TableContext } from './context';
import { TableHeader } from './header';
import styles from './styles.module.css';
import type { Key } from '@react-types/shared';
import type { TableProps } from './types';

// This width is for columns in the table that provide features:
// - Row count
// - Row actions kebab
// - Row selection (checkbox)
// These columns should not need to grow with table width
const META_COLUMN_WIDTH = 32;

type RowActionsMenuProps<T> = {
  row: Row<T>;
  rows: Row<T>[];
  moveRowsDown: (row: Row<T>, rows: Row<T>[]) => void;
  moveRowsUp: (row: Row<T>, rows: Row<T>[]) => void;
};

function RowActionsMenu<T>({
  moveRowsDown,
  moveRowsUp,
  row,
  rows,
}: RowActionsMenuProps<T>) {
  const { enableRowActions, persistRowKebabMenu } = useContext(TableContext);
  const isPinned = !!row.getIsPinned();
  const hideRowKebab = !persistRowKebabMenu;

  return (
    enableRowActions && (
      <div className={clsx(hideRowKebab && styles.hideInRow)}>
        <MenuTrigger>
          <Button variant='icon' aria-label={`row ${row.index + 1} actions`}>
            <Icon>
              <Kebab />
            </Icon>
          </Button>
          <Menu>
            <MenuItem onAction={() => row.pin(isPinned ? false : 'top')}>
              {isPinned ? 'Unpin' : 'Pin'}
            </MenuItem>
            <MenuSeparator />
            <MenuItem
              onAction={() => moveRowsUp(row, rows)}
              isDisabled={isPinned || row.index === 0}
            >
              Move Up
            </MenuItem>
            <MenuItem
              onAction={() => moveRowsDown(row, rows)}
              isDisabled={isPinned || row.index === rows.length - 1}
            >
              Move Down
            </MenuItem>
          </Menu>
        </MenuTrigger>
      </div>
    )
  );
}

/**
 * Table - Configurable data table with sorting, selection, and row actions
 *
 * Supports data-driven mode with TanStack column definitions or static mode with subcomponents.
 *
 * @param props - {@link TableProps}
 * @param props.children - Custom children for static mode.
 * @param props.columns - Column definitions for data-driven mode.
 * @param props.data - Data array for data-driven mode.
 * @param props.showCheckbox - Whether to show selection checkboxes.
 * @param props.rowSelection - Initial row selection state.
 * @param props.kebabPosition - Position of row action menu.
 * @param props.persistRowKebabMenu - Keep row kebab menu visible.
 * @param props.persistHeaderKebabMenu - Keep header kebab menu visible.
 * @param props.persistNumerals - Keep row numerals visible.
 * @param props.enableSorting - Enable column sorting.
 * @param props.enableColumnReordering - Enable column reordering.
 * @param props.enableRowActions - Enable row action menu.
 * @param props.manualSorting - Use server-side sorting.
 * @param props.onSortChange - Callback when sort changes.
 * @param props.onColumnReorderChange - Callback when column order changes.
 * @param props.onRowSelectionChange - Callback when row selection changes.
 * @param props.fullWidth - Whether table uses full width.
 * @returns The rendered Table component.
 *
 * @example
 * ```tsx
 * <Table columns={columns} data={rows} enableSorting showCheckbox />
 * ```
 */
export function Table<T extends { id: Key }>({
  children,
  columns: columnsProp,
  data: dataProp,
  showCheckbox,
  rowSelection: rowSelectionProp,
  kebabPosition = 'right',
  persistRowKebabMenu = true,
  persistHeaderKebabMenu = true,
  persistNumerals = false,
  enableSorting = true,
  enableColumnReordering = true,
  enableRowActions = true,
  manualSorting = false,
  onSortChange,
  onColumnReorderChange,
  onRowSelectionChange,
  fullWidth = false,
  ...rest
}: TableProps<T>) {
  const {
    items: data,
    moveAfter,
    moveBefore,
  } = useListData({
    initialItems: dataProp,
  });
  const [rowSelection, setRowSelection] = useState<RowSelectionState>(
    rowSelectionProp ?? {},
  );
  const [columnSelection, setColumnSelection] = useState<string | null>(null);
  const [rowPinning, setRowPinning] = useState<RowPinningState>({
    top: [],
    bottom: [],
  });

  /**
   * moveUpSelectedRows moves the selected rows up in the table.
   * It finds the first selected row, determines its index,
   * and moves it before the previous row if it exists.
   */
  const moveRowsUp = useCallback(
    (row: Row<T>, rows: Row<T>[]) => {
      const isSelected = rowSelection[row.id];
      const rowsToMove = isSelected
        ? rows.filter(({ id }) => rowSelection[id])
        : [row];
      const firstRowToMove = rowsToMove[0];

      if (!firstRowToMove || firstRowToMove.index === 0) {
        return;
      }

      const prevRowId = rows[firstRowToMove.index - 1]?.id;

      if (!prevRowId) {
        return;
      }

      moveBefore(
        prevRowId,
        rowsToMove.map(({ id }) => id),
      );
    },
    [rowSelection, moveBefore],
  );

  /**
   * moveDownRows moves the selected or active rows down in the table.
   * It finds the last selected row, determines its index,
   * and moves it after the next row if it exists.
   */
  const moveRowsDown = useCallback(
    (row: Row<T>, rows: Row<T>[]) => {
      const isSelected = rowSelection[row.id];
      const rowsToMove = isSelected
        ? rows.filter(({ id }) => rowSelection[id])
        : [row];
      const lastRowToMove = rowsToMove[rowsToMove.length - 1];

      if (!lastRowToMove || lastRowToMove.index === rows.length - 1) {
        return;
      }

      const nextRowId = rows[lastRowToMove.index + 1]?.id;

      if (!nextRowId) {
        return;
      }

      moveAfter(
        nextRowId,
        rowsToMove.map(({ id }) => id),
      );
    },
    [rowSelection, moveAfter],
  );

  /**
   * actionColumn defines the actions available in the kebab menu for each row.
   * It includes options to move the row up or down in the table.
   */
  // biome-ignore lint/correctness/useExhaustiveDependencies: can of worms to fix ticket added
  const actionColumn: NonNullable<typeof columnsProp>[number] = useMemo(
    () => ({
      id: 'kebab',
      cell: ({ row }) => (
        <RowActionsMenu
          moveRowsUp={moveRowsUp}
          moveRowsDown={moveRowsDown}
          row={row}
          rows={getRowModel().rows}
        />
      ),
      size: META_COLUMN_WIDTH,
    }),
    [moveRowsUp, moveRowsDown],
  );

  /**
   * columns defines the structure of the table.
   * It includes the action column and optionally a checkbox column.
   * The kebab menu position can be set to 'left' or 'right'.
   * If showCheckbox is true, a checkbox column is added.
   */
  const columns = useMemo<NonNullable<typeof columnsProp>>(
    () => [
      {
        id: 'numeral',
        cell: ({ row }) =>
          row.getIsPinned() ? (
            <Icon size='small'>
              <Pin />
            </Icon>
          ) : (
            <span data-testid='numeral'>{row.index + 1}</span>
          ),
        size: META_COLUMN_WIDTH,
      },
      ...(showCheckbox
        ? ([
            {
              id: 'selection',
              header: ({ table }) => (
                <Checkbox
                  isSelected={table.getIsAllRowsSelected()}
                  isIndeterminate={table.getIsSomeRowsSelected()}
                  onChange={table.toggleAllRowsSelected}
                />
              ),
              cell: ({ row }) => (
                <Checkbox
                  isSelected={row.getIsSelected()}
                  isIndeterminate={row.getIsSomeSelected()}
                  onChange={row.toggleSelected}
                />
              ),
              size: META_COLUMN_WIDTH,
            },
          ] satisfies NonNullable<typeof columnsProp>)
        : []),
      ...(kebabPosition === 'left' ? [actionColumn] : []),
      ...(columnsProp ?? []),
      ...(kebabPosition === 'right' ? [actionColumn] : []),
    ],
    [showCheckbox, columnsProp, kebabPosition, actionColumn],
  );

  const handleSortChange = (
    columnId: string,
    sortDirection: 'asc' | 'desc' | null,
  ) => {
    onSortChange?.(columnId, sortDirection);
  };

  const handleColumnReordering = (index: number) => {
    onColumnReorderChange?.(index);
  };

  const handleRowSelectionChange = useCallback(
    (
      updaterOrValue:
        | RowSelectionState
        | ((old: RowSelectionState) => RowSelectionState),
    ) => {
      setRowSelection(updaterOrValue);
      onRowSelectionChange?.(updaterOrValue);
    },
    [onRowSelectionChange],
  );

  const {
    getHeaderGroups,
    getTopRows,
    getCenterRows,
    getBottomRows,
    getRowModel,
    setColumnOrder,
  } = useReactTable<T>({
    data,
    columns,
    enableSorting,
    initialState: {
      columnOrder: columns.map(({ id }) => id ?? ''),
      rowSelection: rowSelectionProp ?? {},
    },
    state: {
      rowSelection,
      rowPinning,
    },
    getRowId: (row, index) => {
      // Use the index as the row ID if no unique identifier is available
      return row.id ? row.id.toString() : index.toString();
    },
    enableRowSelection: true,
    enableRowPinning: true,
    manualSorting: manualSorting,
    onRowSelectionChange: handleRowSelectionChange,
    onRowPinningChange: setRowPinning,
    getCoreRowModel: getCoreRowModel<T>(),
    getSortedRowModel: getSortedRowModel<T>(),
  });

  const moveColumnLeft = useCallback(
    (oldIndex: number) => {
      setColumnOrder((order) => {
        const newColumnOrder = [...order];
        const newIndex = oldIndex - 1;

        if (newIndex < 0) {
          return order;
        }

        [newColumnOrder[oldIndex], newColumnOrder[newIndex]] = [
          newColumnOrder[newIndex] as string,
          newColumnOrder[oldIndex] as string,
        ];

        return newColumnOrder;
      });
    },
    [setColumnOrder],
  );

  const moveColumnRight = useCallback(
    (oldIndex: number) => {
      setColumnOrder((order) => {
        const newColumnOrder = [...order];
        const newIndex = oldIndex + 1;

        if (newIndex >= order.length) {
          return order;
        }

        [newColumnOrder[oldIndex], newColumnOrder[newIndex]] = [
          newColumnOrder[newIndex] as string,
          newColumnOrder[oldIndex] as string,
        ];

        return newColumnOrder;
      });
    },
    [setColumnOrder],
  );

  const className = clsx(fullWidth && 'w-full table-fixed', rest.className);

  if (children) {
    return (
      <table {...rest} className={className}>
        {children}
      </table>
    );
  }

  return (
    <TableContext.Provider
      value={{
        persistRowKebabMenu,
        persistHeaderKebabMenu,
        persistNumerals,
        enableSorting,
        enableColumnReordering,
        enableRowActions,
        columnSelection,
        setColumnSelection,
        moveColumnLeft,
        moveColumnRight,
        manualSorting,
        handleSortChange,
        handleColumnReordering,
      }}
    >
      <table {...rest} className={className}>
        <TableHeader
          headerGroups={getHeaderGroups()}
          columnSelection={columnSelection}
        />
        <TableBody
          rows={[...getTopRows(), ...getCenterRows(), ...getBottomRows()]}
        />
      </table>
    </TableContext.Provider>
  );
}
