/*
 * Copyright 2025 Hypergiant Galactic Systems Inc. All rights reserved.
 * This file is licensed to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 * OF ANY KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */

import type { RefAttributes } from 'react';
import type {
  ListLayoutOptions as AriaListLayoutOptions,
  SelectProps as AriaSelectProps,
  VirtualizerProps as AriaVirtualizerProps,
  FieldErrorProps,
  PopoverProps,
} from 'react-aria-components';
import type { ButtonProps } from '../button/types';
import type { LabelProps } from '../label/types';

/**
 * Props for SelectField component.
 *
 * Extends AriaSelectProps with form field features and virtualization.
 * - `classNames.description` - CSS class for the description text.
 * - `classNames.error` - CSS class for the error message.
 * - `classNames.field` - CSS class for the field container.
 * - `classNames.label` - CSS class for the label.
 * - `classNames.trigger` - CSS class for the trigger button.
 * - `classNames.value` - CSS class for the selected value display.
 * - `classNames.popover` - CSS class for the dropdown popover.
 * - `label` - Label text for the field.
 * - `description` - Helper text below the field.
 * - `errorMessage` - Error message displayed when invalid.
 * - `isReadOnly` - Displays value without dropdown interaction.
 * - `size` - Field size ('medium' or 'small').
 */
export type SelectFieldProps = Omit<AriaSelectProps, 'className'> &
  Pick<AriaVirtualizerProps<AriaListLayoutOptions>, 'layoutOptions'> &
  RefAttributes<HTMLDivElement> & {
    classNames?: {
      description?: string;
      error?: FieldErrorProps['className'];
      field?: string;
      label?: LabelProps['className'];
      trigger?: ButtonProps['className'];
      value?: string;
      popover?: PopoverProps['className'];
    };
    label?: string;
    description?: string;
    errorMessage?: string;
    isReadOnly?: boolean;
    size?: 'medium' | 'small';
  };
