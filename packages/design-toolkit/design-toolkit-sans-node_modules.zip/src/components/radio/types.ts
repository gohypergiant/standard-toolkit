/*
 * Copyright 2025 Hypergiant Galactic Systems Inc. All rights reserved.
 * This file is licensed to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 * OF ANY KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */

import type { RefAttributes } from 'react';
import type {
  RadioGroupProps as AriaRadioGroupProps,
  RadioProps as AriaRadioProps,
} from 'react-aria-components';
import type { LabelProps } from '../label/types';

/**
 * Props for RadioGroup component.
 *
 * Extends AriaRadioGroupProps with custom classNames and label support.
 * - `classNames.group` - CSS class for the radio group container.
 * - `classNames.label` - CSS class for the group label.
 * - `label` - Optional text label for the group.
 */
export type RadioGroupProps = Omit<AriaRadioGroupProps, 'className'> &
  RefAttributes<HTMLDivElement> & {
    classNames?: {
      group?: AriaRadioGroupProps['className'];
      label?: LabelProps['className'];
    };
    label?: string;
  };

/**
 * Props for Radio component.
 *
 * Extends AriaRadioProps with custom classNames support.
 * - `classNames.radio` - CSS class for the radio label wrapper.
 * - `classNames.control` - CSS class for the radio button control.
 * - `classNames.label` - CSS class for the radio label text.
 */
export type RadioProps = Omit<AriaRadioProps, 'className'> &
  RefAttributes<HTMLLabelElement> & {
    classNames?: {
      radio?: AriaRadioProps['className'];
      control?: string;
      label?: string;
    };
  };
