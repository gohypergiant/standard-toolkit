/*
 * Copyright 2025 Hypergiant Galactic Systems Inc. All rights reserved.
 * This file is licensed to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 * OF ANY KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
'use client';

import 'client-only';
import { clsx } from '@accelint/design-foundation/lib/utils';
import {
  RadioGroup as AriaRadioGroup,
  composeRenderProps,
  useContextProps,
} from 'react-aria-components';
import { Label } from '../label';
import { RadioContext } from './context';
import styles from './styles.module.css';
import type { RadioGroupProps } from './types';

/**
 * RadioGroup - Container component for Radio buttons
 *
 * Groups related Radio components and manages their selection state.
 * Only one Radio can be selected at a time within a RadioGroup.
 *
 * @example
 * ```tsx
 * <RadioGroup label="Size" value="medium" onChange={setValue}>
 *   <Radio value="small">Small</Radio>
 *   <Radio value="medium">Medium</Radio>
 *   <Radio value="large">Large</Radio>
 * </RadioGroup>
 * ```
 *
 * @param props - {@link RadioGroupProps}
 * @param props.ref - Forwarded ref for the group container.
 * @param props.classNames - Custom CSS class names for group and label.
 * @param props.label - Optional text label for the group.
 * @param props.children - Radio components to render inside the group.
 * @returns The rendered RadioGroup component.
 */
export function RadioGroup({ ref, ...props }: RadioGroupProps) {
  [props, ref] = useContextProps(props, ref ?? null, RadioContext);

  const { children, classNames, label, ...rest } = props;

  return (
    <AriaRadioGroup
      {...rest}
      ref={ref}
      className={composeRenderProps(classNames?.group, (className) =>
        clsx('group/radio-group', styles.group, className),
      )}
    >
      {composeRenderProps(children, (children, { isDisabled, isRequired }) => (
        <>
          {label && (
            <Label
              className={clsx(styles.label, classNames?.label)}
              isDisabled={isDisabled}
              isRequired={isRequired}
            >
              {label}
            </Label>
          )}
          {children}
        </>
      ))}
    </AriaRadioGroup>
  );
}
